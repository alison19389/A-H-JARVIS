package com.ahjarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var listening by mutableStateOf(false)
    private val requestAudio = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { if (it) startListening() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisScreen() }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR")
    }

    private fun startListening() {
        listening = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o AH JARVIS")
        }
        startActivityForResult(intent, 10)
    }

    @Deprecated("Android callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        listening = false
        if (requestCode == 10 && resultCode == Activity.RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) respond(text)
        }
    }

    private fun respond(command: String) {
        val lower = command.lowercase(Locale("pt", "BR"))
        val response = when {
            "olá" in lower || "oi" in lower -> "Olá. Sou o AH JARVIS. Como posso ajudar?"
            "seu nome" in lower -> "Meu nome é AH JARVIS."
            "horas" in lower -> "Consulte o horário exibido no seu celular."
            "obrigado" in lower || "obrigada" in lower -> "Sempre à disposição."
            else -> "Entendi: $command. A conexão com uma IA externa ainda precisa ser configurada."
        }
        tts?.speak(response, TextToSpeech.QUEUE_FLUSH, null, "AHJARVIS")
    }

    @Composable
    fun JarvisScreen() {
        var status by remember { mutableStateOf("PRONTO PARA COMANDO") }
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF05070D)) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("AH JARVIS", color = Color(0xFF62D9FF), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text(status, color = Color.LightGray, fontSize = 13.sp)
                Spacer(Modifier.height(45.dp))
                Button(
                    onClick = {
                        status = "OUVINDO..."
                        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                            requestAudio.launch(Manifest.permission.RECORD_AUDIO)
                        else startListening()
                    },
                    modifier = Modifier.size(190.dp),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF123B55))
                ) {
                    Text(if (listening) "OUVINDO" else "FALAR", color = Color.White, fontSize = 20.sp)
                }
                Spacer(Modifier.height(28.dp))
                Text("Assistente de voz • Português (Brasil)", color = Color.Gray)
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
