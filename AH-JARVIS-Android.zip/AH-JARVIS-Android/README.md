# AH JARVIS — Android

Projeto inicial de um assistente de voz inspirado em interfaces futuristas.

Inclui:
- reconhecimento de voz em português;
- respostas faladas;
- interface futurista;
- comandos locais básicos.

Para transformar este projeto em um APK, ele precisa ser compilado em um ambiente Android/Gradle (por exemplo, Android Studio ou um serviço de build). Este pacote é o código-fonte pronto para compilação.
